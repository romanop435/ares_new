--[[


addons/[weapons]_cw_20/lua/cw/shared/colors/cw_lasercolors.lua

--]]

local clr = {}
clr.name = "laser_red"
clr.display = "Red"
clr.color = Color(255, 75, 75, 255)

CustomizableWeaponry.colorableParts:addLaserColor(clr)

local clr = {}
clr.name = "laser_green"
clr.display = "Green"
clr.color = Color(100, 255, 100, 255)

CustomizableWeaponry.colorableParts:addLaserColor(clr)

local clr = {}
clr.name = "laser_blue"
clr.display = "Blue"
clr.color = Color(150, 150, 255, 255)

CustomizableWeaponry.colorableParts:addLaserColor(clr)

local clr = {}
clr.name = "laser_gold"
clr.display = "Gold"
clr.color = Color(250, 255, 0, 255)

CustomizableWeaponry.colorableParts:addLaserColor(clr)

local clr = {}
clr.name = "laser_turquoise"
clr.display = "Turquoise"
clr.color = Color(48, 213, 200, 255)

CustomizableWeaponry.colorableParts:addLaserColor(clr)