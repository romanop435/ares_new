--[[


addons/[weapons]_no_260_kk_ins2/lua/cw/shared/grenadetypes/40mm_kk_1337.lua

--]]


// gmad.exe suxdix
// cant simply ignore empty file
