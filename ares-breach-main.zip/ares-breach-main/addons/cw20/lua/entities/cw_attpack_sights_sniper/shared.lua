--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_sights_sniper/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Sights - sniper"
ENT.PackageText = "Sniper sights"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"md_nightforce_nxs"}