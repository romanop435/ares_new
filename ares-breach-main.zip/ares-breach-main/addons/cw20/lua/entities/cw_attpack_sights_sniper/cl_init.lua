--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_sights_sniper/cl_init.lua

--]]

include("shared.lua")