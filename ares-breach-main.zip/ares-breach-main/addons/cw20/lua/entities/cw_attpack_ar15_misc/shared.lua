--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ar15_misc/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AR-15 - miscellaneous"
ENT.PackageText = "AR-15 Miscellaneous"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_foldsight", "md_anpeq15", "md_saker", "md_m203", "bg_ar1560rndmag"}