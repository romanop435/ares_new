--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_mr96_barrels/cl_init.lua

--]]

include("shared.lua")