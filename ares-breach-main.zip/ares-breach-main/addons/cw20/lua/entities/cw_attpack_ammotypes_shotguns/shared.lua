--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ammotypes_shotguns/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Ammo types - shotguns"
ENT.PackageText = "Shotgun ammo types"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"am_slugrounds", "am_flechetterounds"}