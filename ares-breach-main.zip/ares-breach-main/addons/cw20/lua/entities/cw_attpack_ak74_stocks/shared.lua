--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ak74_stocks/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AK-74 - stocks package"
ENT.PackageText = "AK-74 Stocks"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_ak74foldablestock", "bg_ak74heavystock"}