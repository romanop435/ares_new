--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_projectile_molotov_doi/cl_init.lua

--]]

include("shared.lua")
