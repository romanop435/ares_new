--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_projectile_molotov_doi/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_kk_ins2_projectile_molotov"
ENT.PrintName = "Thrown incendiary grenade"
ENT.Author = "KK"
ENT.Information = "Thrown incendiary grenade"
ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Model = "models/weapons/w_projectile_eintoss.mdl"
