AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

ENT.CollisionGroup = COLLISION_GROUP_DEBRIS