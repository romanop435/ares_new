--[[


addons/[weapons]_cw_20/lua/entities/cw_smoke_912/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Thrown smoke grenade"
ENT.Author = "Spy"
ENT.Information = "Thrown smoke grenade"
ENT.Spawnable = false
ENT.AdminSpawnable = false 