ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = ".338 Lapua Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 30
ENT.ResupplyAmount = 5
ENT.Caliber = ".338 Lapua"
ENT.Model = "models/Items/BoxMRounds.mdl"