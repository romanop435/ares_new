--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_deagle_barrels/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Deagle - barrels"
ENT.PackageText = "Deagle Barrels"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_deagle_compensator", "bg_deagle_extendedbarrel"}