--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_various/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Various attachments"
ENT.PackageText = "Various"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_foldsight", "md_foregrip", "md_anpeq15", "md_m203"}