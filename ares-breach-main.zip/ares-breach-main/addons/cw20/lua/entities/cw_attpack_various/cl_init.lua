--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_various/cl_init.lua

--]]

include("shared.lua")