--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_projectile_n69/shared.lua

--]]

if not CustomizableWeaponry then return end

ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Activated frag grenade"
ENT.Author = "Spy"
ENT.Information = "Activated frag grenade"
ENT.Spawnable = false
ENT.AdminSpawnable = false

CustomizableWeaponry:addRegularSound("CW_KK_INS2_DOI_N69_ENT_BOUNCE", {"weapons/no69/no69_bounce_01.wav", "weapons/no69/no69_bounce_02.wav", "weapons/no69/no69_bounce_03.wav", "weapons/no69/no69_bounce_04.wav"})
