--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_attpack_suppressors/cl_init.lua

--]]

include("shared.lua")
