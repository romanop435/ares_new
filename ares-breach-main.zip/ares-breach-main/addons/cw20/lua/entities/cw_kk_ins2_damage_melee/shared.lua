--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_damage_melee/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.Spawnable = false
ENT.AdminSpawnable = false
