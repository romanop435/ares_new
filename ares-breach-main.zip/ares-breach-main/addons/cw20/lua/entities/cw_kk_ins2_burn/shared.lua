--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_burn/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "attach point for fire dmg"
ENT.Author = "KK"
ENT.Information = "attach point for fire dmg"
ENT.Spawnable = false
ENT.AdminSpawnable = false
