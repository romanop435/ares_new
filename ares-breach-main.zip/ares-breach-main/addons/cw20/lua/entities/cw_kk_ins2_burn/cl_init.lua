--[[


addons/[weapons]_no_260_kk_ins2/lua/entities/cw_kk_ins2_burn/cl_init.lua

--]]

include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
end

function ENT:Think()
	self:StopParticles()
end
