ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AR-15 - long barrels"
ENT.PackageText = "AR-15 Long barrels"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_longbarrel", "bg_longris"}