--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ak74_barrels/cl_init.lua

--]]

include("shared.lua")