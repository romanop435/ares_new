--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ammotypes_rifles/cl_init.lua

--]]

include("shared.lua")