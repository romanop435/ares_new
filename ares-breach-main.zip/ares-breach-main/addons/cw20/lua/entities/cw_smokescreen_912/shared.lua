--[[


addons/[weapons]_cw_20/lua/entities/cw_smokescreen_912/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Smoke impact position"
ENT.Author = "Spy"
ENT.Spawnable = false
ENT.AdminSpawnable = false 

ENT.SmokeDuration = 16