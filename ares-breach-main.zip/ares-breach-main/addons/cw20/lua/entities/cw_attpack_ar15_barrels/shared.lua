--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ar15_barrels/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AR-15 - barrels package"
ENT.PackageText = "AR-15 CQB barrels"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_ris", "bg_magpulhandguard"}