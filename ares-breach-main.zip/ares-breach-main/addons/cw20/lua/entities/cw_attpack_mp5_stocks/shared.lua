--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_mp5_stocks/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "MP5 - stocks"
ENT.PackageText = "MP5 Stocks"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_retractablestock", "bg_nostock"}