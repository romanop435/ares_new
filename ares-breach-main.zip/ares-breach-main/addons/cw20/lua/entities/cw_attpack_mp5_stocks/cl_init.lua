--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_mp5_stocks/cl_init.lua

--]]

include("shared.lua")