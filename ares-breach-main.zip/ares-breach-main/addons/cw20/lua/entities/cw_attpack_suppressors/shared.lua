--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_suppressors/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Various suppressors"
ENT.PackageText = "Suppressors"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"md_pbs1", "md_saker", "md_tundra9mm", "md_cobram2"}