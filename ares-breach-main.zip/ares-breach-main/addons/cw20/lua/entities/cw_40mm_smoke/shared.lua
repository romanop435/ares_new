ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "40MM Smoke grenade"
ENT.Author = "Spy"
ENT.Spawnable = false
ENT.AdminSpawnable = false 
