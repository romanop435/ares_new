--[[


addons/[weapons]_cw_20/lua/entities/cw_ammo_9x19/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = "9x19MM Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 120
ENT.ResupplyAmount = 30
ENT.Caliber = "9x19MM"
ENT.Model = "models/Items/BoxSRounds.mdl"