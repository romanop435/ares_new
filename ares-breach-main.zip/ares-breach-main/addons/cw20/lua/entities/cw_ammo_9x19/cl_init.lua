--[[


addons/[weapons]_cw_20/lua/entities/cw_ammo_9x19/cl_init.lua

--]]

include("shared.lua")

ENT.upOffset = Vector(0, 0, 28)