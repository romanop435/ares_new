--[[


addons/[weapons]_cw_20/lua/entities/cw_attpack_ar15_stocks/shared.lua

--]]

ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AR-15 - stocks package"
ENT.PackageText = "AR-15 Stocks"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_ar15sturdystock", "bg_ar15heavystock"}