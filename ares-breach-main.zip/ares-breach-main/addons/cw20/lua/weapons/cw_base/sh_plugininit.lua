--[[


addons/[weapons]_cw_20/lua/weapons/cw_base/sh_plugininit.lua

--]]

CustomizableWeaponry.quickGrenade:initializeQuickGrenade()