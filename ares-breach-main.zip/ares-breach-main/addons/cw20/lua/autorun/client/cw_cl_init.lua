--[[


addons/[weapons]_cw_20/lua/autorun/client/cw_cl_init.lua

--]]

include("cw/client/cw_clientmenu.lua")
include("cw/client/cw_hud.lua")
include("cw/client/cw_umsgs.lua")
include("cw/client/cw_hooks.lua")
include("cw/client/cw_statdisplay.lua")