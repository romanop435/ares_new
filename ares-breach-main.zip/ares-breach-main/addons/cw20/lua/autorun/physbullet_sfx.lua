AddCSLuaFile( )

game.AddDecal( "Decal.PhysBullet.Incendiary", "decals/scorch_incendiary" )

game.AddDecal( "Decal.PhysBullet.Ricochet", "decals/ricochet" )
