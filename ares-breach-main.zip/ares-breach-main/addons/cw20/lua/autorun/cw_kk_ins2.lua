--[[


addons/[weapons]_no_260_kk_ins2/lua/autorun/cw_kk_ins2.lua

--]]

AddCSLuaFile()

local main = "cw_kk/ins2/main.lua"
AddCSLuaFile(main)
include(main)
