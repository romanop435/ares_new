--[[


addons/[weapons]_no_260_kk_ins2/lua/cw_kk/ins2/client/nodraw_materials.lua

--]]


CustomizableWeaponry_KK.ins2.nodrawMatPath = "models/weapons/attachments/cw_kk_ins2_shared/nodraw"

CustomizableWeaponry_KK.ins2.nodrawMat = CustomizableWeaponry_KK.ins2.nodrawMat or {}
-- CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/4x_reticule"] = true

CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/elcan_reticule"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/po4x_reticule"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/mosin_crosshair"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/mk4_crosshair"] = true

CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/enfield_crosshair"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/kar98k_crosshair"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/weaver_crosshair"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/zf4_crosshair"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/optics/fg42_crosshair"] = true

CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/l85a2/susat_reticle"] = true

CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/nam/svd/po4x_reticule"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/nam/m16a1/colt_scope_reticule"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/nam/optics/pu/po4x_reticule"] = true
CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/nam/optics/elcan_reticule"] = true

CustomizableWeaponry_KK.ins2.nodrawMat["models/error/new light1"] = true

-- CustomizableWeaponry_KK.ins2.nodrawMat[""] = true

-- CustomizableWeaponry_KK.ins2.nodrawMat["models/weapons/attachments/cw_kk_ins2_cstm_eotechxps/4x_reticule"] = true
