--[[


addons/[weapons]_no_260_kk_ins2/lua/cw_kk/ins2/shared/artillery.lua

--]]


CustomizableWeaponry_KK.ins2.artillery = CustomizableWeaponry_KK.ins2.artillery or {}
