
-- resource.AddWorkshop("349050451") // CW
-- resource.AddWorkshop("358608166") // ECW
-- resource.AddWorkshop("486217238") // CW MAGS
-- resource.AddWorkshop("707343339") // CW MEL

--resource.AddWorkshop("657241323") // KK INS2
