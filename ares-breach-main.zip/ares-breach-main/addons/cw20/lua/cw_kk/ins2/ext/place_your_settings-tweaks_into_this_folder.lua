--[[


addons/[weapons]_no_260_kk_ins2/lua/cw_kk/ins2/ext/place_your_settings-tweaks_into_this_folder.lua

--]]


-- CustomizableWeaponry_KK.ins2.firstDeployEnabled = true
-- CustomizableWeaponry_KK.ins2.firstDeploySkip = -1
-- CustomizableWeaponry_KK.ins2.holsterTransitionsEnabled = true
-- CustomizableWeaponry_KK.ins2.discardEjectedAmmo = false
