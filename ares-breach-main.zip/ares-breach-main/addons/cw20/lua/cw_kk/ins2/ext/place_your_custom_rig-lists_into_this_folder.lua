--[[


addons/[weapons]_no_260_kk_ins2/lua/cw_kk/ins2/ext/place_your_custom_rig-lists_into_this_folder.lua

--]]

// lalala like this

/*
if CLIENT then
	CustomizableWeaponry_KK.ins2.hands:addModel({"models/weapons/v_hands_short_brit.mdl", "[DOI] GB Short", mergeGMHands = false})
end
// */
